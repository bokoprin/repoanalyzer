package com.bokoprin.modelcolor.data.database

import androidx.room.withTransaction

interface DatabaseTransactionRunner {
    suspend fun <T> run(block: suspend () -> T): T
}

class RoomDatabaseTransactionRunner(
    private val database: AppDatabase,
) : DatabaseTransactionRunner {
    override suspend fun <T> run(block: suspend () -> T): T = database.withTransaction { block() }
}

object DirectDatabaseTransactionRunner : DatabaseTransactionRunner {
    override suspend fun <T> run(block: suspend () -> T): T = block()
}
