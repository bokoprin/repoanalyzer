package com.bokoprin.modelcolor.data.database

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query

@Dao
interface MaskDao {
    @Query(
        """
        SELECT * FROM masks
        WHERE projectId = :projectId
        ORDER BY displayOrder ASC, createdAtEpochMillis ASC
        """,
    )
    suspend fun findAllByProjectId(projectId: String): List<MaskEntity>

    @Query(
        """
        SELECT * FROM masks
        WHERE projectId = :projectId
        ORDER BY displayOrder ASC, createdAtEpochMillis ASC
        LIMIT 1
        """,
    )
    suspend fun findFirstByProjectId(projectId: String): MaskEntity?

    @Query("SELECT * FROM masks WHERE id = :id LIMIT 1")
    suspend fun findById(id: String): MaskEntity?

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insert(entity: MaskEntity)

    @Query(
        """
        UPDATE masks
        SET updatedAtEpochMillis = :updatedAtEpochMillis
        WHERE id = :id
        """,
    )
    suspend fun touch(id: String, updatedAtEpochMillis: Long): Int

    @Query(
        """
        UPDATE masks
        SET sourceWorkingImagePath = :sourceWorkingImagePath,
            updatedAtEpochMillis = :updatedAtEpochMillis
        WHERE id = :id
        """,
    )
    suspend fun updateSourceImage(
        id: String,
        sourceWorkingImagePath: String,
        updatedAtEpochMillis: Long,
    ): Int

    @Query(
        """
        UPDATE masks
        SET name = :name,
            updatedAtEpochMillis = :updatedAtEpochMillis
        WHERE id = :id
        """,
    )
    suspend fun rename(id: String, name: String, updatedAtEpochMillis: Long): Int

    @Query(
        """
        UPDATE masks
        SET isVisible = :isVisible,
            updatedAtEpochMillis = :updatedAtEpochMillis
        WHERE id = :id
        """,
    )
    suspend fun updateVisibility(
        id: String,
        isVisible: Boolean,
        updatedAtEpochMillis: Long,
    ): Int

    @Query(
        """
        UPDATE masks
        SET displayOrder = :displayOrder,
            updatedAtEpochMillis = :updatedAtEpochMillis
        WHERE id = :id
        """,
    )
    suspend fun updateDisplayOrder(
        id: String,
        displayOrder: Int,
        updatedAtEpochMillis: Long,
    ): Int

    @Query("DELETE FROM masks WHERE id = :id")
    suspend fun deleteById(id: String): Int

    @Query("SELECT COUNT(*) FROM masks WHERE projectId = :projectId")
    suspend fun countByProjectId(projectId: String): Int
}
