package com.bokoprin.modelcolor.data.database

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query

@Dao
interface RecentColorDao {
    @Query("SELECT * FROM recent_colors ORDER BY lastUsedAtEpochMillis DESC LIMIT :limit")
    suspend fun findRecent(limit: Int): List<RecentColorEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(entity: RecentColorEntity)

    @Query(
        """
        DELETE FROM recent_colors
        WHERE colorArgb NOT IN (
            SELECT colorArgb FROM recent_colors
            ORDER BY lastUsedAtEpochMillis DESC
            LIMIT :limit
        )
        """,
    )
    suspend fun trimTo(limit: Int)
}
