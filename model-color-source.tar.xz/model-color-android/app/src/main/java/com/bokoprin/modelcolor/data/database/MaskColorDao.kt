package com.bokoprin.modelcolor.data.database

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query

@Dao
interface MaskColorDao {
    @Query(
        """
        SELECT * FROM mask_colors
        WHERE schemeId = :schemeId AND maskId = :maskId
        LIMIT 1
        """,
    )
    suspend fun find(schemeId: String, maskId: String): MaskColorEntity?

    @Query(
        """
        SELECT * FROM mask_colors
        WHERE schemeId = :schemeId
        ORDER BY maskId ASC
        """,
    )
    suspend fun findAllBySchemeId(schemeId: String): List<MaskColorEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(entity: MaskColorEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(entities: List<MaskColorEntity>)
}
