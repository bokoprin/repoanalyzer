package com.bokoprin.modelcolor.data.database

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index

@Entity(
    tableName = "mask_colors",
    primaryKeys = ["schemeId", "maskId"],
    foreignKeys = [
        ForeignKey(
            entity = ColorSchemeEntity::class,
            parentColumns = ["id"],
            childColumns = ["schemeId"],
            onDelete = ForeignKey.CASCADE,
        ),
        ForeignKey(
            entity = MaskEntity::class,
            parentColumns = ["id"],
            childColumns = ["maskId"],
            onDelete = ForeignKey.CASCADE,
        ),
    ],
    indices = [Index(value = ["maskId"])],
)
data class MaskColorEntity(
    val schemeId: String,
    val maskId: String,
    val colorArgb: Long,
    val opacity: Float,
    val updatedAtEpochMillis: Long,
)
