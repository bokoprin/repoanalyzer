package com.bokoprin.modelcolor.data.database

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface ProjectDao {
    @Query(
        """
        SELECT * FROM projects
        ORDER BY updatedAtEpochMillis DESC, createdAtEpochMillis DESC
        """,
    )
    fun observeAll(): Flow<List<ProjectEntity>>

    @Query("SELECT * FROM projects WHERE id = :id LIMIT 1")
    suspend fun findById(id: String): ProjectEntity?

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insert(entity: ProjectEntity)

    @Query(
        """
        UPDATE projects
        SET name = :name, updatedAtEpochMillis = :updatedAtEpochMillis
        WHERE id = :id
        """,
    )
    suspend fun rename(
        id: String,
        name: String,
        updatedAtEpochMillis: Long,
    ): Int

    @Query(
        """
        UPDATE projects
        SET sourceImagePath = :sourceImagePath,
            workingImagePath = :workingImagePath,
            thumbnailPath = :thumbnailPath,
            imageWidth = :imageWidth,
            imageHeight = :imageHeight,
            updatedAtEpochMillis = :updatedAtEpochMillis
        WHERE id = :id
        """,
    )
    suspend fun updateImage(
        id: String,
        sourceImagePath: String,
        workingImagePath: String,
        thumbnailPath: String,
        imageWidth: Int,
        imageHeight: Int,
        updatedAtEpochMillis: Long,
    ): Int

    @Query(
        """
        UPDATE projects
        SET activeSchemeId = :activeSchemeId,
            updatedAtEpochMillis = :updatedAtEpochMillis
        WHERE id = :id
        """,
    )
    suspend fun updateActiveScheme(
        id: String,
        activeSchemeId: String,
        updatedAtEpochMillis: Long,
    ): Int

    @Query("DELETE FROM projects WHERE id = :id")
    suspend fun deleteById(id: String): Int

    @Query("SELECT COUNT(*) FROM projects")
    suspend fun count(): Int
}
