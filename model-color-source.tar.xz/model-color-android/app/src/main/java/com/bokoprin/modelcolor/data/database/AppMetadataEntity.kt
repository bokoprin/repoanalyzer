package com.bokoprin.modelcolor.data.database

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "app_metadata")
data class AppMetadataEntity(
    @PrimaryKey val id: String,
    val createdAtEpochMillis: Long,
)
