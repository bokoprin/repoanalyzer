package com.bokoprin.modelcolor.data.database

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query

@Dao
interface AppMetadataDao {
    @Query("SELECT * FROM app_metadata WHERE id = :id LIMIT 1")
    suspend fun findById(id: String): AppMetadataEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(entity: AppMetadataEntity)
}
