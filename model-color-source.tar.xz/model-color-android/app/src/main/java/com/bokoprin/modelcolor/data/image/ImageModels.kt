package com.bokoprin.modelcolor.data.image

import android.net.Uri

data class CameraCaptureTarget(
    val uri: Uri,
    val filePath: String,
)

data class ImageImportDraft(
    val id: String,
    val sourcePath: String,
    val previewPath: String,
    val sourceExtension: String,
    val width: Int,
    val height: Int,
)

data class ProjectImageFiles(
    val sourceImagePath: String,
    val workingImagePath: String,
    val thumbnailPath: String,
    val imageWidth: Int,
    val imageHeight: Int,
)
