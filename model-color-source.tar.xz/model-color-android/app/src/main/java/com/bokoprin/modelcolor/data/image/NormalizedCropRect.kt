package com.bokoprin.modelcolor.data.image

import kotlin.math.max
import kotlin.math.min

/** A crop rectangle expressed in normalized image coordinates (0f..1f). */
data class NormalizedCropRect(
    val left: Float,
    val top: Float,
    val right: Float,
    val bottom: Float,
) {
    init {
        require(left in 0f..1f) { "left must be within 0..1" }
        require(top in 0f..1f) { "top must be within 0..1" }
        require(right in 0f..1f) { "right must be within 0..1" }
        require(bottom in 0f..1f) { "bottom must be within 0..1" }
        require(left < right) { "left must be smaller than right" }
        require(top < bottom) { "top must be smaller than bottom" }
    }

    val width: Float get() = right - left
    val height: Float get() = bottom - top

    fun moveCorner(
        corner: CropCorner,
        x: Float,
        y: Float,
        minimumSize: Float = MinimumSize,
    ): NormalizedCropRect {
        require(minimumSize in 0f..1f)
        val clampedX = x.coerceIn(0f, 1f)
        val clampedY = y.coerceIn(0f, 1f)
        return when (corner) {
            CropCorner.TopLeft -> copy(
                left = min(clampedX, right - minimumSize).coerceAtLeast(0f),
                top = min(clampedY, bottom - minimumSize).coerceAtLeast(0f),
            )

            CropCorner.TopRight -> copy(
                right = max(clampedX, left + minimumSize).coerceAtMost(1f),
                top = min(clampedY, bottom - minimumSize).coerceAtLeast(0f),
            )

            CropCorner.BottomLeft -> copy(
                left = min(clampedX, right - minimumSize).coerceAtLeast(0f),
                bottom = max(clampedY, top + minimumSize).coerceAtMost(1f),
            )

            CropCorner.BottomRight -> copy(
                right = max(clampedX, left + minimumSize).coerceAtMost(1f),
                bottom = max(clampedY, top + minimumSize).coerceAtMost(1f),
            )
        }
    }

    companion object {
        const val MinimumSize: Float = 0.05f
        val Full: NormalizedCropRect = NormalizedCropRect(0f, 0f, 1f, 1f)
    }
}

enum class CropCorner {
    TopLeft,
    TopRight,
    BottomLeft,
    BottomRight,
}
