package com.bokoprin.modelcolor.data.database

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "recent_colors")
data class RecentColorEntity(
    @PrimaryKey val colorArgb: Long,
    val lastUsedAtEpochMillis: Long,
)
