package com.bokoprin.modelcolor.data.repository

import com.bokoprin.modelcolor.data.database.ProjectDao
import com.bokoprin.modelcolor.data.database.ProjectEntity
import com.bokoprin.modelcolor.data.image.ImageImportManager
import com.bokoprin.modelcolor.data.image.ProjectImageFiles
import com.bokoprin.modelcolor.domain.model.Project
import com.bokoprin.modelcolor.domain.model.ProjectNameRules
import java.io.File
import java.util.UUID
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

interface ProjectRepository {
    fun observeProjects(): Flow<List<Project>>

    suspend fun findProject(projectId: String): Project?

    suspend fun createProject(name: String): Project

    suspend fun renameProject(projectId: String, name: String)

    suspend fun updateProjectImage(projectId: String, imageFiles: ProjectImageFiles)

    suspend fun deleteProject(projectId: String)
}

class OfflineProjectRepository(
    private val projectDao: ProjectDao,
    private val imageImportManager: ImageImportManager? = null,
    private val idGenerator: () -> String = { UUID.randomUUID().toString() },
    private val clock: () -> Long = System::currentTimeMillis,
) : ProjectRepository {
    override fun observeProjects(): Flow<List<Project>> =
        projectDao.observeAll().map { entities -> entities.map(ProjectEntity::toDomain) }

    override suspend fun findProject(projectId: String): Project? =
        projectDao.findById(projectId)?.toDomain()

    override suspend fun createProject(name: String): Project {
        val normalizedName = ProjectNameRules.requireValid(name)
        val now = clock()
        val entity = ProjectEntity(
            id = idGenerator(),
            name = normalizedName,
            sourceImagePath = null,
            workingImagePath = null,
            thumbnailPath = null,
            imageWidth = null,
            imageHeight = null,
            activeSchemeId = null,
            createdAtEpochMillis = now,
            updatedAtEpochMillis = now,
        )
        projectDao.insert(entity)
        return entity.toDomain()
    }

    override suspend fun renameProject(projectId: String, name: String) {
        val normalizedName = ProjectNameRules.requireValid(name)
        val updatedRows = projectDao.rename(
            id = projectId,
            name = normalizedName,
            updatedAtEpochMillis = clock(),
        )
        check(updatedRows == 1) { "Project not found: $projectId" }
    }

    override suspend fun updateProjectImage(
        projectId: String,
        imageFiles: ProjectImageFiles,
    ) {
        val previousProject = projectDao.findById(projectId)
            ?: error("Project not found: $projectId")
        val updatedRows = projectDao.updateImage(
            id = projectId,
            sourceImagePath = imageFiles.sourceImagePath,
            workingImagePath = imageFiles.workingImagePath,
            thumbnailPath = imageFiles.thumbnailPath,
            imageWidth = imageFiles.imageWidth,
            imageHeight = imageFiles.imageHeight,
            updatedAtEpochMillis = clock(),
        )
        check(updatedRows == 1) { "Project not found: $projectId" }

        listOfNotNull(
            previousProject.sourceImagePath,
            previousProject.workingImagePath,
            previousProject.thumbnailPath,
        )
            .filterNot { oldPath ->
                oldPath == imageFiles.sourceImagePath ||
                    oldPath == imageFiles.workingImagePath ||
                    oldPath == imageFiles.thumbnailPath
            }
            .forEach { oldPath -> runCatching { File(oldPath).delete() } }
    }

    override suspend fun deleteProject(projectId: String) {
        val deletedRows = projectDao.deleteById(projectId)
        check(deletedRows == 1) { "Project not found: $projectId" }
        try {
            imageImportManager?.deleteProjectFiles(projectId)
        } catch (cancellation: CancellationException) {
            throw cancellation
        } catch (_: Throwable) {
            // The database row is already gone; orphaned private files can be reclaimed later.
        }
    }
}

private fun ProjectEntity.toDomain(): Project = Project(
    id = id,
    name = name,
    sourceImagePath = sourceImagePath,
    workingImagePath = workingImagePath,
    thumbnailPath = thumbnailPath,
    imageWidth = imageWidth,
    imageHeight = imageHeight,
    activeSchemeId = activeSchemeId,
    createdAtEpochMillis = createdAtEpochMillis,
    updatedAtEpochMillis = updatedAtEpochMillis,
)
