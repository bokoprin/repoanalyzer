package com.bokoprin.modelcolor.data.database

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "projects",
    indices = [Index(value = ["updatedAtEpochMillis"])],
)
data class ProjectEntity(
    @PrimaryKey
    val id: String,
    val name: String,
    val sourceImagePath: String?,
    val workingImagePath: String?,
    val thumbnailPath: String?,
    val imageWidth: Int?,
    val imageHeight: Int?,
    val activeSchemeId: String?,
    val createdAtEpochMillis: Long,
    val updatedAtEpochMillis: Long,
)
