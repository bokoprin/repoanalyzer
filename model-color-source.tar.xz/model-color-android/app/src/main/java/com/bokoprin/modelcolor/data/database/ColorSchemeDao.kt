package com.bokoprin.modelcolor.data.database

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query

@Dao
interface ColorSchemeDao {
    @Query("SELECT * FROM color_schemes WHERE id = :id LIMIT 1")
    suspend fun findById(id: String): ColorSchemeEntity?

    @Query(
        """
        SELECT * FROM color_schemes
        WHERE projectId = :projectId
        ORDER BY createdAtEpochMillis ASC, id ASC
        """,
    )
    suspend fun findAllByProjectId(projectId: String): List<ColorSchemeEntity>

    @Query(
        """
        SELECT * FROM color_schemes
        WHERE projectId = :projectId
        ORDER BY createdAtEpochMillis ASC, id ASC
        LIMIT 1
        """,
    )
    suspend fun findFirstByProjectId(projectId: String): ColorSchemeEntity?

    @Query("SELECT COUNT(*) FROM color_schemes WHERE projectId = :projectId")
    suspend fun countByProjectId(projectId: String): Int

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insert(entity: ColorSchemeEntity)

    @Query(
        """
        UPDATE color_schemes
        SET name = :name, updatedAtEpochMillis = :updatedAtEpochMillis
        WHERE id = :id
        """,
    )
    suspend fun rename(id: String, name: String, updatedAtEpochMillis: Long): Int

    @Query("DELETE FROM color_schemes WHERE id = :id")
    suspend fun deleteById(id: String): Int
}
