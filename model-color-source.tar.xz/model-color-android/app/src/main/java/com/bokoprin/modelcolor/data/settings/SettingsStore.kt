package com.bokoprin.modelcolor.data.settings

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private const val SETTINGS_FILE_NAME = "model_color_settings"
private val Context.settingsDataStore by preferencesDataStore(name = SETTINGS_FILE_NAME)

class SettingsStore(
    private val context: Context,
) {
    val hasSeenIntroduction: Flow<Boolean> = context.settingsDataStore.data.map { preferences ->
        preferences[Keys.HasSeenIntroduction] ?: false
    }

    suspend fun setHasSeenIntroduction(value: Boolean) {
        context.settingsDataStore.edit { preferences ->
            preferences[Keys.HasSeenIntroduction] = value
        }
    }

    internal object Keys {
        val HasSeenIntroduction = booleanPreferencesKey("has_seen_introduction")
    }
}
