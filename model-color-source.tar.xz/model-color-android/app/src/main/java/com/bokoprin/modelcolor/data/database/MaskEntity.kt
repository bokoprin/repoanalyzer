package com.bokoprin.modelcolor.data.database

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "masks",
    foreignKeys = [
        ForeignKey(
            entity = ProjectEntity::class,
            parentColumns = ["id"],
            childColumns = ["projectId"],
            onDelete = ForeignKey.CASCADE,
        ),
    ],
    indices = [
        Index(value = ["projectId"]),
        Index(value = ["projectId", "displayOrder"]),
    ],
)
data class MaskEntity(
    @PrimaryKey
    val id: String,
    val projectId: String,
    val name: String,
    val bitmapPath: String,
    val sourceWorkingImagePath: String,
    val displayOrder: Int,
    val isVisible: Boolean,
    val createdAtEpochMillis: Long,
    val updatedAtEpochMillis: Long,
)
