package com.bokoprin.modelcolor.data.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

@Database(
    entities = [
        AppMetadataEntity::class,
        ProjectEntity::class,
        MaskEntity::class,
        ColorSchemeEntity::class,
        MaskColorEntity::class,
        RecentColorEntity::class,
    ],
    version = 4,
    exportSchema = true,
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun appMetadataDao(): AppMetadataDao
    abstract fun projectDao(): ProjectDao
    abstract fun maskDao(): MaskDao
    abstract fun colorSchemeDao(): ColorSchemeDao
    abstract fun maskColorDao(): MaskColorDao
    abstract fun recentColorDao(): RecentColorDao

    companion object {
        private const val DatabaseName = "model-color.db"

        val Migration1To2: Migration = object : Migration(1, 2) {
            override fun migrate(database: SupportSQLiteDatabase) {
                database.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `projects` (
                        `id` TEXT NOT NULL,
                        `name` TEXT NOT NULL,
                        `sourceImagePath` TEXT,
                        `workingImagePath` TEXT,
                        `thumbnailPath` TEXT,
                        `imageWidth` INTEGER,
                        `imageHeight` INTEGER,
                        `activeSchemeId` TEXT,
                        `createdAtEpochMillis` INTEGER NOT NULL,
                        `updatedAtEpochMillis` INTEGER NOT NULL,
                        PRIMARY KEY(`id`)
                    )
                    """.trimIndent(),
                )
                database.execSQL(
                    """
                    CREATE INDEX IF NOT EXISTS `index_projects_updatedAtEpochMillis`
                    ON `projects` (`updatedAtEpochMillis`)
                    """.trimIndent(),
                )
            }
        }

        val Migration2To3: Migration = object : Migration(2, 3) {
            override fun migrate(database: SupportSQLiteDatabase) {
                database.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `masks` (
                        `id` TEXT NOT NULL,
                        `projectId` TEXT NOT NULL,
                        `name` TEXT NOT NULL,
                        `bitmapPath` TEXT NOT NULL,
                        `sourceWorkingImagePath` TEXT NOT NULL,
                        `displayOrder` INTEGER NOT NULL,
                        `isVisible` INTEGER NOT NULL,
                        `createdAtEpochMillis` INTEGER NOT NULL,
                        `updatedAtEpochMillis` INTEGER NOT NULL,
                        PRIMARY KEY(`id`),
                        FOREIGN KEY(`projectId`) REFERENCES `projects`(`id`)
                            ON UPDATE NO ACTION ON DELETE CASCADE
                    )
                    """.trimIndent(),
                )
                database.execSQL(
                    """
                    CREATE INDEX IF NOT EXISTS `index_masks_projectId`
                    ON `masks` (`projectId`)
                    """.trimIndent(),
                )
                database.execSQL(
                    """
                    CREATE INDEX IF NOT EXISTS `index_masks_projectId_displayOrder`
                    ON `masks` (`projectId`, `displayOrder`)
                    """.trimIndent(),
                )
            }
        }

        val Migration3To4: Migration = object : Migration(3, 4) {
            override fun migrate(database: SupportSQLiteDatabase) {
                database.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `color_schemes` (
                        `id` TEXT NOT NULL,
                        `projectId` TEXT NOT NULL,
                        `name` TEXT NOT NULL,
                        `createdAtEpochMillis` INTEGER NOT NULL,
                        `updatedAtEpochMillis` INTEGER NOT NULL,
                        PRIMARY KEY(`id`),
                        FOREIGN KEY(`projectId`) REFERENCES `projects`(`id`)
                            ON UPDATE NO ACTION ON DELETE CASCADE
                    )
                    """.trimIndent(),
                )
                database.execSQL(
                    """
                    CREATE INDEX IF NOT EXISTS `index_color_schemes_projectId`
                    ON `color_schemes` (`projectId`)
                    """.trimIndent(),
                )
                database.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `mask_colors` (
                        `schemeId` TEXT NOT NULL,
                        `maskId` TEXT NOT NULL,
                        `colorArgb` INTEGER NOT NULL,
                        `opacity` REAL NOT NULL,
                        `updatedAtEpochMillis` INTEGER NOT NULL,
                        PRIMARY KEY(`schemeId`, `maskId`),
                        FOREIGN KEY(`schemeId`) REFERENCES `color_schemes`(`id`)
                            ON UPDATE NO ACTION ON DELETE CASCADE,
                        FOREIGN KEY(`maskId`) REFERENCES `masks`(`id`)
                            ON UPDATE NO ACTION ON DELETE CASCADE
                    )
                    """.trimIndent(),
                )
                database.execSQL(
                    """
                    CREATE INDEX IF NOT EXISTS `index_mask_colors_maskId`
                    ON `mask_colors` (`maskId`)
                    """.trimIndent(),
                )
                database.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `recent_colors` (
                        `colorArgb` INTEGER NOT NULL,
                        `lastUsedAtEpochMillis` INTEGER NOT NULL,
                        PRIMARY KEY(`colorArgb`)
                    )
                    """.trimIndent(),
                )
            }
        }

        fun create(context: Context): AppDatabase =
            Room.databaseBuilder(
                context.applicationContext,
                AppDatabase::class.java,
                DatabaseName,
            )
                .addMigrations(Migration1To2, Migration2To3, Migration3To4)
                .build()
    }
}
