package com.bokoprin.modelcolor.app

import android.content.Context
import com.bokoprin.modelcolor.data.color.ColorSettingsRepository
import com.bokoprin.modelcolor.data.color.OfflineColorSettingsRepository
import com.bokoprin.modelcolor.data.database.AppDatabase
import com.bokoprin.modelcolor.data.database.RoomDatabaseTransactionRunner
import com.bokoprin.modelcolor.data.export.ImageExportManager
import com.bokoprin.modelcolor.data.export.LocalImageExportManager
import com.bokoprin.modelcolor.data.image.ImageImportManager
import com.bokoprin.modelcolor.data.image.LocalProjectHealthChecker
import com.bokoprin.modelcolor.data.image.ProjectHealthChecker
import com.bokoprin.modelcolor.data.image.LocalImageImportManager
import com.bokoprin.modelcolor.data.mask.LocalMaskFileStore
import com.bokoprin.modelcolor.data.mask.MaskFileStore
import com.bokoprin.modelcolor.data.mask.MaskRepository
import com.bokoprin.modelcolor.data.mask.OfflineMaskRepository
import com.bokoprin.modelcolor.data.repository.OfflineProjectRepository
import com.bokoprin.modelcolor.data.repository.ProjectRepository
import com.bokoprin.modelcolor.data.settings.SettingsStore
import java.io.File

interface AppContainer {
    val database: AppDatabase
    val imageImportManager: ImageImportManager
    val imageExportManager: ImageExportManager
    val projectHealthChecker: ProjectHealthChecker
    val projectRepository: ProjectRepository
    val maskFileStore: MaskFileStore
    val maskRepository: MaskRepository
    val colorSettingsRepository: ColorSettingsRepository
    val settingsStore: SettingsStore
}

class DefaultAppContainer(
    private val context: Context,
) : AppContainer {
    override val database: AppDatabase by lazy(LazyThreadSafetyMode.SYNCHRONIZED) {
        AppDatabase.create(context)
    }

    override val imageImportManager: ImageImportManager by lazy(LazyThreadSafetyMode.SYNCHRONIZED) {
        LocalImageImportManager(context.applicationContext)
    }

    override val imageExportManager: ImageExportManager by lazy(LazyThreadSafetyMode.SYNCHRONIZED) {
        LocalImageExportManager(context.applicationContext)
    }

    override val projectHealthChecker: ProjectHealthChecker by lazy(LazyThreadSafetyMode.SYNCHRONIZED) {
        LocalProjectHealthChecker()
    }

    override val maskFileStore: MaskFileStore by lazy(LazyThreadSafetyMode.SYNCHRONIZED) {
        LocalMaskFileStore(File(context.filesDir, "projects"))
    }

    override val maskRepository: MaskRepository by lazy(LazyThreadSafetyMode.SYNCHRONIZED) {
        OfflineMaskRepository(
            maskDao = database.maskDao(),
            maskFileStore = maskFileStore,
        )
    }

    override val colorSettingsRepository: ColorSettingsRepository by lazy(
        LazyThreadSafetyMode.SYNCHRONIZED,
    ) {
        OfflineColorSettingsRepository(
            projectDao = database.projectDao(),
            colorSchemeDao = database.colorSchemeDao(),
            maskColorDao = database.maskColorDao(),
            recentColorDao = database.recentColorDao(),
            transactionRunner = RoomDatabaseTransactionRunner(database),
        )
    }

    override val projectRepository: ProjectRepository by lazy(LazyThreadSafetyMode.SYNCHRONIZED) {
        OfflineProjectRepository(
            projectDao = database.projectDao(),
            imageImportManager = imageImportManager,
        )
    }

    override val settingsStore: SettingsStore by lazy(LazyThreadSafetyMode.SYNCHRONIZED) {
        SettingsStore(context)
    }
}
